<?php

$i=10;
echo "Dvoznamenkasti brojevi djeljivi s 3 i 5 ili s oba: <br/>";
while($i<=99)
{
 if(($i%3==0 && $i%5==0) || ($i%3==0 || $i%5==0) )
 {
	echo "$i  ";
 }
 $i++;
}

?>