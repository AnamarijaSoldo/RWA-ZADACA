<?php

$brojevi = array( 1, 22, 3, 4, 5, 99, 12, 49, 14, 23, 7);

$suma=0;
foreach($brojevi as $value){
$suma+=$value;
}
echo "Suma brojeva je $suma.";

?>