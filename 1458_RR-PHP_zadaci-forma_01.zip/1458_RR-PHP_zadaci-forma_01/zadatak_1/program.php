<?php
if (isset($_GET['tekst'])) { 

$tekst=$_GET['tekst']; 
$broj=$_GET['broj'];
echo "ISPIS <br/>";
for($i=1; $i<=$broj; $i++){
echo "$i. $tekst <br/>";
}
}
else { 
header('Location: tekst.html'); 
} 
?>