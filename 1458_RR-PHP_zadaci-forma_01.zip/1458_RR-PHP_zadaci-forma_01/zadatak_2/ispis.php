<html>
<body>
    <h3>Odaberite opciju:</h3>
	<form name="forma" method="get" action="ispis.php">
	<input type="submit" name="a" value="A"/>
	<input type="submit" name="b" value="B"/>
	<input type="submit" name="c" value="C"/>
	</form>

<?php
if(isset($_GET['a']))
echo "Odabrali ste dugme A";

else if(isset($_GET['b']))
echo "Odabrali ste dugme B";

else if(isset($_GET['c']))
echo "Odabrali ste dugme C";

else {
echo "Niste odabrali nijedno dugme";
}
?>

</body>
</html>